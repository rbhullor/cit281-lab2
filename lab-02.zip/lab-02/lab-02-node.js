/*
    CIT 281 Lab 2
    Name: Reiya Bhullor
*/

console.log(`Square of 20 is ${square(10)}`);